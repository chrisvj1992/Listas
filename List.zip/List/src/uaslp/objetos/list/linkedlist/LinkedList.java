package uaslp.objetos.list.linkedlist;

import uaslp.objetos.list.Iterator;
import uaslp.objetos.list.List;

public class LinkedList implements List {
    private Node head;
    private Node tail;
    private int size;

    private static class Node {
        Node next;
        Node previous;
        String data;

        public Node(String data) {
            this.data = data;
        }

    }

    private static class LinkedListIterator implements Iterator {
        private Node current;


        public LinkedListIterator(Node head){
            this.current = head;
        }

        public boolean hasNext(){
            return current != null;
        }
        public String next(){
            String data = current.data;
            current = current.next;
            return data;
        }
    }





    public void addAtTail(String data){
        Node node = new Node(data);
        node.previous = tail;
        tail = node;

        if( head == null) {
            head = node;
        }else {
            node.previous.next = node;
        }
        size++;
    }
    public void addAtFront(String data){
        Node node = new Node(data);
        node.next= head;
        head = node;

        if( tail == null) {
            tail = node;
        }else{
            node.next.previous = node;
        }
        size++;
    }

    public int getSize(){
        return size;
    }

    public boolean remove(int indexToRemove){

        if(indexToRemove < 0 || indexToRemove >= size){
            return false;
        }if(size ==1){      //if this is the last, set null the attributes
            head = null;
            tail = null;
            size = 0;
        } else if(indexToRemove == 0){  //this is the first element
            head = head.next;
            head.previous = null;
        } else if (indexToRemove == size -1) { // if is the last element
            tail = tail.previous;
            tail.next = null;
        } else{
            Node iteratorNode = findNodeByIndex(indexToRemove);

            iteratorNode.previous.next = iteratorNode.next;
            iteratorNode.next.previous = iteratorNode.previous;

        }
        size--;
        return true;
    }

    public void removeAll(){
        head = null;
        tail = null;
        size = 0;
    }
    public void removeAllWithValue(String value){
        Node current = head;

        while(current != null){
            if(current.data.equals(value)){
                if(current == head){
                    head = current.next;
                    if(head == null){
                        tail = null;
                    }else{
                        head.previous = null;
                    }
                }else{
                    current.previous.next = current.next;
                    if (current == tail){
                        tail = current.previous;
                    }else{
                        current.next.previous = current.previous;
                    }
                }
            }
            current = current.next;
        }
    }

    public boolean setAt(int index,String data){
        if(index < 0 || index >= size){
            return false;
        }
        Node node = findNodeByIndex(index);
        node.data = data;
        return true;
    }

    public String getAt(int index){
        if(index < 0 || index >= size){
            return null;
        }
        Node node = findNodeByIndex(index);
        return node.data;
    }

    private Node findNodeByIndex(int index) {
        Node iteratorNode = head;
        int indexIteratorNode = 0;

        while (indexIteratorNode < index){
            iteratorNode = iteratorNode.next;
            indexIteratorNode++;
        }
        return iteratorNode;
    }

    public LinkedListIterator getIterator(){
        return new LinkedListIterator(head);
    }
}
